# Jrpg Fragment - Overworld
Overworld map for a JRPG

## About
This asset contains an example of a typical overworld aspect of a JRPG.

## Author
* mechPenSketch

## Acknowledgements
* [Metadata-Inspector](https://github.com/ballerburg9005/godot-metadata-inspector) by ballerburg9005 is used to add metadata in Godot editor.
